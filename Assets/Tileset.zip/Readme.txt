Here is my tilemap.
The tiles are 32x32x.

There is also aseprite versio of the tilemap if you want to edit the tiles.

LICENCE: This asset pack can be used in both free and commercial projects. 
You can modify it to suit your own needs. Credit is not necessary, but appreciated.  
You may not redistribute it or resell it.